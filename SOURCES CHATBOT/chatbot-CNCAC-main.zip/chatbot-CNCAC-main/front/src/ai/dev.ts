import { config } from 'dotenv';
config();

import '@/ai/flows/summarize-conversation-title.ts';